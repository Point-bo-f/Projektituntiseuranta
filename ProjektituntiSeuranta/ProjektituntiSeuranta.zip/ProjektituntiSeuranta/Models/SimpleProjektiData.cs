﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjektituntiSeuranta.Models
{
    public class SimpleProjektiData
    {
        public int ProjektiID { get; set; }
        public int HenkiloID { get; set; }
        public int Projektitunnit { get; set; }

    }
}